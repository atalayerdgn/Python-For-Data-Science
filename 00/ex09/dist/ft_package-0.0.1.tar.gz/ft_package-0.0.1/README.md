This is a simple example package.
